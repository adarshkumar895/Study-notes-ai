# Study Notes AI — Full Starter

यह version user के लिए लगभग पूरा starter है: registration/login, SQLite database, YouTube transcript attempt, OpenAI notes, Razorpay ₹29/₹149, server-side signature verification, Razorpay webhook, PDF download और admin stats.

## आपको सिर्फ 5 काम करने हैं
1. इस folder को किसी Node.js hosting/server पर upload करें.
2. `npm install` चलाएँ.
3. `.env.example` को `.env` बनाकर अपनी keys भरें.
4. `npm start` चलाएँ.
5. Razorpay dashboard में webhook URL `https://YOUR-DOMAIN/api/webhook/razorpay` और वही webhook secret रखें.

### Required keys
- OPENAI_API_KEY: OpenAI dashboard से
- RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET: Razorpay dashboard से
- RAZORPAY_WEBHOOK_SECRET: Razorpay webhook में आप स्वयं secret सेट करें
- JWT_SECRET: कोई लंबा random secret

**Secrets chat/GitHub में कभी paste न करें.** Razorpay भी API secrets को source control में न रखने की सलाह देता है. See official security guidance.

## Pricing
- Single note: ₹29
- Monthly: ₹149

## Production checklist
- Custom domain + HTTPS
- Privacy Policy / Terms / Refund Policy
- Razorpay KYC/business onboarding
- YouTube/transcript provider terms का पालन
- Backups, rate limiting, monitoring
- Monthly plan के लिए recurring subscription entitlement को production में Razorpay Subscriptions से जोड़ना
- Admin dashboard को proper role/2FA से secure करना

Razorpay payment gateway supports orders, payments and webhooks; server-side signature verification और webhook validation production में जरूरी हैं.
